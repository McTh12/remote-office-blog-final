
export default function DeskAccessories() {
  return (
    <div>
      <h1>Best Desk Accessories for Maximum Focus</h1>
      <p>Upgrade your desk setup. Don’t miss the <a href="https://www.amazon.com/dp/B09XYZ" target="_blank" rel="noopener noreferrer">LED Monitor Light Bar</a>.</p>
    </div>
  );
}
