# Remote Office Blog (Flat)

Deploy-ready Next.js affiliate blog — all files in root.

## Deploy Instructions

1. Upload to GitHub
2. Deploy on Vercel (no need to set a Root Directory)
3. Done!
